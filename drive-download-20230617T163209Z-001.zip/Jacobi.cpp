#include <iostream>
#include <math.h>

using namespace std;

//Variables globales
int n,imax,numit;
double A[100][100],x0[100],x1[100],epsilon;

void llenarMatriz()
{
	double s=0;
	
	for(int i = 0; i <= n; i++)
	{
		for(int j = 0; j <= n+1; j++)
		{
			cout<<"\nIngrese el elemento ["<<i<<"]["<<j<<"] de la matriz: "; cin>>s;
			A[i][j]=s;
		}
	}
}

void solucionInicial()
{
	double s = 0;

	for(int i = 0; i <=n; i++)
	{
		cout<<"\nIngrese el elemento ["<<i<<"] de la solucion propuesta"; cin>>s;
		x0[i]=s;
	}
}

void DatosDeEntrada()
{
	cout<<"\n-----DATOS DE ENTRADA-----"
	
	cout<<"\nIngrese la cantidad de iteraciones: "; cin>>imax;
	cout<<"\nIngrese el error maximo: "; cin>>epsilon;
	cout<<"\nMatriz Ampliada del sistema";
	llenarMatriz();
	cout<<"\nSolucion Propuesta";
	solucionInicial();
}

void Jacobi()
{
	fin = false;
	double s1,s2;
	int k = 1;

	while(k<=imax && fin == false)
	{
		for(int i=1;i<=n;i++)
		{
			s1=0;
			for(int j = 0; j <= i-1; j++)
			{
				s1 = s1 + A[i][j]*x0[j];
			}
			s2=0;
			for(int j = i+1; j <= n; j++)
			{
				s2 = s2 + A[i][j]*x0[j];
			}

			x1[i] = (A[i][n+1] - s1 - s2 )/A[i][i];
		}

		while(i)
	}
}

int main(int argc, char const *argv[])
{
	return 0;
}

